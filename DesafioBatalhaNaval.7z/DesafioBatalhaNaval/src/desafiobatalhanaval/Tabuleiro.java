/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desafiobatalhanaval;

import java.util.Random;

/**
 *
 * @author Glauco
 */
public class Tabuleiro {
    //atributos da classe tabuleiro
    int tabuleiroPlayer1[][] = new int[5][5];
    int tabuleiroPlayer2[][] = new int[5][5];
    String tabuleiroPlayer1Impresso[][] = new String[5][5];
    String tabuleiroPlayer2Impresso[][] = new String[5][5];
    int acertosPlayer2 = 0;
    int acertosPlayer1 = 0;
    int tentativas = 0;
    int navios = 0;
    int finalizar = 0;

    //Inicia e reinicia os tabuleiros
    void inicializaTabuleiro() {
        navios = 0;
        finalizar = 0;
        acertosPlayer2 = 0;
        acertosPlayer1 = 0;
        tentativas = 0;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                tabuleiroPlayer1[i][j] = -1;
            }
        }

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                tabuleiroPlayer2[i][j] = -1;
            }
        }
    }

    //insere os navios do player1  
    void novoNavio(int x, int y) {
        //valida se a coordenada ja esta ocupada
        if (tabuleiroPlayer1[x][y] != -1) {
            System.out.println("Esta coordenada já está ocupada! \n");
        } else {
            tabuleiroPlayer1[x][y] = 1;
            navios += 1;
        }
    }
    
    //insere os navios do player2
    void novoNavioPC() {
        Random random = new Random();
        int i;
        int j;
        i = random.nextInt(5);
        j = random.nextInt(5);
        
        //verifica se é possivel inserir o navio na coordenada randomica
        if (tabuleiroPlayer2[i][j] == -1) {
            tabuleiroPlayer2[i][j] = 1;
        } else {
            novoNavioPC();
        }

    }

    //preenche o tabuleiro que eh mostrado ao jogador  
    void preencherTabuleiro() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                tabuleiroPlayer1Impresso[i][j] = " ~ ";
                tabuleiroPlayer2Impresso[i][j] = " ~ ";
            }
        }
    }

    //imprimir o tabuleiroPlayer1 e do player2   
    void imprimirTabuleiro() {
        //imprimir o tabuleiro do player1
        System.out.println("");
        System.out.println("Tabuleiro do player1: ");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(tabuleiroPlayer1Impresso[i][j] + " ");
            }
            System.out.println(" ");
        }

        //imprimir o tabuleiro do player2
        System.out.println("");
        System.out.println("Tabuleiro do Player2: ");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(tabuleiroPlayer2Impresso[i][j] + " ");
            }
            System.out.println(" ");
        }
    }

  
    //mostra o tabuleiro do player1 e do player2 a cada tiro
    int atirar(int x, int y) {
           
        //verifica se afundou o navio do player2
        if (tabuleiroPlayer2[x][y] != -1) {
            System.out.println("");
            System.out.println("Você afundou o navio");
            tabuleiroPlayer2Impresso[x][y] = " * ";
            tabuleiroPlayer2[x][y] = 2;
            imprimirTabuleiro();
            acertosPlayer1 += 1;
            tentativas += 1;
            finalizar();
            return acertosPlayer1;

        } else {
            System.out.println("");
            System.out.println("Você não acertou o tiro");
            tabuleiroPlayer2Impresso[x][y] = " x ";
            tabuleiroPlayer2[x][y] = 2;
            imprimirTabuleiro();
            tentativas += 1;
            return acertosPlayer1;
        }
    }

  
    //mostra o tabuleiro do player1 e do player2 a cada tiro
    void atirarPlayer2() {
        Random random = new Random();
        int x;
        int y;
        x = random.nextInt(5);
        y = random.nextInt(5);
        
        //verifica se ja foi dado um tiro na coordenada 
        if (tabuleiroPlayer1[x][y] == 2) {
            atirarPlayer2();
            
        } else //verifica se afundou o navio do player1
        if (tabuleiroPlayer1[x][y] != -1) {
            System.out.println("");
            System.out.println("O Player2 afundou sua embarcação");
            tabuleiroPlayer1Impresso[x][y] = " * ";
            tabuleiroPlayer1[x][y] = 2;
            imprimirTabuleiro();
            acertosPlayer2 += 1;
            finalizar();

        } else {
            System.out.println("");
            System.out.println("O player2 errou o tiro");
            tabuleiroPlayer1Impresso[x][y] = " x ";
            tabuleiroPlayer1[x][y] = 2;
            imprimirTabuleiro();
        }

    }
    
    //metodo para verificar quem foi o vencedor
    void finalizar(){
        if (acertosPlayer1 == navios) {
            System.out.println("--------------------------------------------");
            System.out.println("VOCE AFUNDOU TODAS OS NAVIOS INIMIGAS");
            System.out.println("Número de tentativas: " + tentativas);
            System.out.println("");
            finalizar = 1;
            
        } else if (acertosPlayer2 == navios) {
            System.out.println("");
            System.out.println("O PLAYER 2 AFUNDOU TODAS AS SEUS NAVIOS");
            System.out.println("");
            finalizar = 1;
        }
    }
}
