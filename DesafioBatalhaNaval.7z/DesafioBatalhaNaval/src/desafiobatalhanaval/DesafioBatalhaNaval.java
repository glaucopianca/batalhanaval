/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desafiobatalhanaval;

import java.util.Scanner;

/**
 *
 * @author Glauco
 */
public class DesafioBatalhaNaval {

    Tabuleiro tab = new Tabuleiro();
    Scanner sc = new Scanner(System.in);
    int op = 0;
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc1 = new Scanner(System.in);
        DesafioBatalhaNaval dbn = new DesafioBatalhaNaval();       
        
        //menu
        do {
        System.out.println("1. CARREGAR TABULEIRO");
        System.out.println("2. ADICIONAR NAVIO");
        System.out.println("3. ATIRAR");
        System.out.println("9. SAIR");
        System.out.println("Digite a opção desejada: ");
        dbn.op = Integer.parseInt(sc1.nextLine());
        
        
        switch(dbn.op) {
            case 1:
                dbn.carregarTabuleiro();
                System.out.println("Preparando o tabuleiro");            
                break;
                
            case 2:
                dbn.novoNavio();
                break;

            case 3:
                dbn.atirar();
                break;
                
            case 9:
                System.out.println("Saindo");
                break;                
                
            default:
                System.out.println("Opcao invalida");
        }
        
        }while(dbn.op != 9);
    }

    
    
 
    //chama os metodos para inicializacao e preenchimento dos tabuleiros
    void carregarTabuleiro(){

        tab.inicializaTabuleiro();
        tab.preencherTabuleiro();
    }
    
    //inserindo os navios
    void novoNavio(){
        DesafioBatalhaNaval dbn = new DesafioBatalhaNaval();
        int x = 0;
        int y = 0;
        
        //verica se nao excedeu o numero maximo de navios
        if (tab.navios != 3){
        System.out.println("Digite a posição X do seu navio(1 a 5)");
        x = Integer.parseInt(sc.nextLine()) - 1;
        //verifica se a coordenada eh valida
        if ((x > 5) || (x < 0)){
            System.out.println("Valor inválido");
            dbn.novoNavio();
        }
        
        System.out.println("Digite a posição Y do seu navio(1 a 5)");
        y = Integer.parseInt(sc.nextLine()) - 1;
        //verifica se a coordenada eh valida
        if ((y > 5) || (y < 0)){
            System.out.println("");
            System.out.println("Valor inválida");
            dbn.novoNavio();
        }
        
        //chama os metodos responsaveis por inserir os navios do player e do pc
        tab.novoNavio(x, y);
        tab.novoNavioPC();
        }
        
        else {
            System.out.println("");
            System.out.println("Impossivel adicionar mais navios");
        }
    }
    
    void atirar(){
        DesafioBatalhaNaval dbn = new DesafioBatalhaNaval();
        int x = 0;
        int y = 0;
        
        //Laço "do while" que so se encerra quando todas as embarcacoes do player ou do pc sao afundadas
        do {
            System.out.println("");
            System.out.println("Digite a posição X do seu tiro(1 a 5)");
            x = Integer.parseInt(sc.nextLine()) - 1;
            //verifica se a coordenada eh valida
                if ((x > 5) || (x < 0)){
                System.out.println("Valor inválido");
                dbn.atirar();
            }
            System.out.println("");
            System.out.println("Digite a posição Y do seu tiro(1 a 5)");
            y = Integer.parseInt(sc.nextLine()) - 1;
            //verifica se a coordenada eh valida
                if ((y > 5) || (y < 0)){
                    System.out.println("");
                    System.out.println("Valor inválido");
                    dbn.atirar();
                    
                }
                tab.atirar(x, y);  

                    
            //verifica se o player afundou todas as embarcacoes do pc antes da vez do pc
            if (tab.finalizar != 1) {
                System.out.println("");
                System.out.println("Player 2: ");
                tab.atirarPlayer2();
            }

        } while (tab.finalizar != 1);
           
    }
}